//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by winvnc.rc
//
#define IDR_MANIFEST                    1
#define IDI_ICON                        101
#define IDR_TRAY                        102
#define IDD_DIALOG1                     103
#define IDD_ABOUT                       104
#define IDI_CONNECTED                   105
#define IDR_VNCVIEWER_JAR               106
#define IDD_QUERY_CONNECT               107
#define IDD_ADD_NEW_CLIENT              108
#define IDB_BITMAP                      109
#define IDC_DESCRIPTION                 1000
#define IDC_BUILDTIME                   1001
#define IDC_VERSION                     1002
#define IDC_COPYRIGHT                   1003
#define IDC_QUERY_COUNTDOWN             1008
#define IDC_QUERY_USER                  1009
#define IDC_QUERY_HOST                  1010
#define IDC_HOST                        1011
#define ID_OPTIONS                      40001
#define ID_CLOSE                        40002
#define ID_ABOUT                        40003
#define ID_DISCONNECT                   40004
#define ID_CONNECT                      40005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
